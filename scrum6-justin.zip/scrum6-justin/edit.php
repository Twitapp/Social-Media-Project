<!DOCTYPE html>
<html>
	<head>
		<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" />
		<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
    <title>Profile</title>

    <style>

        nav {
          background-color:#ff0000;
          height:115px;
          position:fixed;
          margin-bottom:5px;
          z-index:100;
        }

        #logo {
          width:80px;
          height:80px;
          margin-right:25px;
          margin-top:10px;
        }

        .body {
          float:right;
          width:65%;
        }

        #welcome {
          margin-top:100px;
          margin-right:25px;
        }

        .combined-row {
          width:30%;
          position:absolute;
          margin-top:-5px;
          float:left;
          margin-left:25px;
        }

        #search {
          margin-top:100px;
        }

        #make-tweet {
          margin-top:310px;
        }

        #post-tweet {
          border-radius:10px;
          border-color: #b2b2b2;
          width:330px;
          height:104px;
          padding:7px;
        }

        #latest-tweets {
          padding-top:-20px;
          position:relative;
          margin-top:-10px;
          margin-right:25px;
          clear:both;
        }

        .page-footer {
          background-color:#ff0000;
          clear:both;
        }

    </style>
	</head>
	<body style="background-color:#fcfcfc">

    <div>

        <nav>
          <div class="nav-wrapper">
            <a href="#" class="brand-logo center" style="margin-top:-15px"><h1><strong>Twitter</strong></h1></a>
            <ul id="nav-mobile" class="left hide-on-med-and-down">
                <li><a href="edit.php">Home</a></li>
                <li><a href="logout.php">Logout</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="help.php">Help</a></li>
                <li><a href="about.php">About</a></li>
            </ul>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <li><img id="logo" src="twitter-logo-orange.png" /></li>
            </ul>
          </div>
        </nav>
    	
    <br>

    <div id="welcome" class="body" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content white-text">
            	<span class="card-title">
            <?php
						// pass in some info;
						require("common.php"); 
		
						if(empty($_SESSION['user'])) { 
  
							// If they are not, we redirect them to the login page. 
							$location = "http://" . $_SERVER['HTTP_HOST'] . "/login.php";
							echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
							//exit;
         
        					// Remember that this die statement is absolutely critical.  Without it, 
        					// people can view your members-only content without logging in. 
        					die("Redirecting to login.php");
    					}
		
						// To access $_SESSION['user'] values put in an array, show user his username
						$arr = array_values($_SESSION['user']);
						echo "<h5 style='color:black'>Your Feed, " . "<strong>" . $arr[1] . "</strong>" . ":</h5>";
   					?>
   				     </span>
            </div>
          </div>
        </div>
    </div>


    <div id="search" class="combined-row" class="row">
      <div class="col s12 m6">
          <div class="card white">
              <div class="card-content black-text">
              <span class="card-title"></span>
                  <br>
                  <form action="search.php" method="post">
                      <input placeholder="Search for hashtags or tweets by other users..." type="text" name="search">
                      <br>
                      <button class="waves-effect waves-light btn-large" type="submit" name="action" style="background-color:red">Search</button>
                  </form>
              </div>
          </div>
      </div>
    </div>

    <div id="make-tweet" class="combined-row" class="row">
        <div class="col s12 m6">
          <div class="card white">
            <div class="card-content black-text">
              <span class="card-title"></span>
              <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
              <textarea id="post-tweet" placeholder="Tweet a message..." class="form-control" type="text" name="tweet" rows="5" cols="4" id="comment" style="border-radius:5px"></textarea><br><br>
                <button class="waves-effect waves-light btn-large" type="submit" name="action" style="background-color:red">Tweet</button>
              </form>
            </div>
          </div>
        </div>
    </div>

    <div id="latest-tweets" class="body" class="row">
      <div class="col s12 m6">
        <div class="card white">
          <div class="card-content white-text">
            <br>

	<?php

		// open connection
		$connection = mysqli_connect($host, $username, $password) or die ("Unable to connect!");

		// select database
		mysqli_select_db($connection, $dbname) or die ("Unable to select database!");

		// create query
		$query = "SELECT * FROM symbols";
       
		// execute query
		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
		

		// see if any rows were returned
		if (mysqli_num_rows($result) > 0) {

        // print them one after another
        echo "<table cellpadding=10 border=1>";
        while($row = mysqli_fetch_row($result)) {
            echo "<tr>";
            //echo "<td>".$row[0]."</td>";
            echo "<td style='color:black'><strong>" . $row[1]."</strong> tweeted:</td>";
            echo "<td style='color:black'>".$row[2]."</td>";
            echo "<td><a style='color:black' href=".$_SERVER['PHP_SELF']."?id=".$row[0]."><u>Remove Tweet</u></a></td>";
            echo "</tr>";
        }
        echo "</table>";

    } else {
			
    		// print status message
    		echo "No rows found!";
		}

		// free result set memory
		mysqli_free_result($connection,$result);

		// set variable values to HTML form inputs
		$usernm = '@'.$arr[1];
    $tweet = $_POST['tweet'];
		
		// check to see if user has entered anything
		if ($tweet != "") {

	 		// build SQL query
			$query = "INSERT INTO symbols (username, tweet) VALUES ('$usernm', '$tweet')";
			// run the query
     	$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
			// refresh the page to show new update
	 		echo "<meta http-equiv='refresh' content='0'>";
		}

		
		// if DELETE pressed, set an id, if id is set then delete it from DB
		if (isset($_GET['id'])) {

			// create query to delete record
			echo $_SERVER['PHP_SELF'];
    		$query = "DELETE FROM symbols WHERE id = ".$_GET['id'];

			// run the query
     		$result = mysqli_query($connection,$query) or die ("Error in query: $query. ".mysql_error());
			
			// reset the url to remove id $_GET variable
			$location = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
			echo '<META HTTP-EQUIV="refresh" CONTENT="0;URL='.$location.'">';
			exit;
			
		}
		
		// close connection
		mysqli_close($connection);

	?>

		      </div>
        </div>
      </div>
    </div>

    </div>


  <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>

	</body>
</html>