-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: May 17, 2017 at 11:39 PM
-- Server version: 5.6.35
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `neeljustindb`
--
CREATE DATABASE IF NOT EXISTS `neeljustindb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `neeljustindb`;

-- --------------------------------------------------------

--
-- Table structure for table `symbols`
--

CREATE TABLE `symbols` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL DEFAULT '',
  `image` text NOT NULL,
  `description` text NOT NULL,
  `likes` int(11) NOT NULL,
  `timedate` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `symbols`
--

INSERT INTO `symbols` (`id`, `username`, `image`, `description`, `likes`, `timedate`) VALUES
(71, 'jgilbert3', '', 'hi', 11, 'May 16, 2017 at 8:52 am'),
(72, 'jgilbert', '', 'hello', 0, 'May 17, 2017 at 3:18 pm');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `salt` char(16) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `salt`, `email`) VALUES
(4, 'joe', '2da8829d571c7eb4fe0d16b699f4f85f873b7b042a763afa13449264bb4017ca', '37ef77e53bf3e4f0', 'joe@blow.com'),
(7, 'jgilbert', 'a6cc3d5226704ab9fbf68aff8b01279efcce980ba56b698b94122f3871a9bfd5', '7ad549296d2e3b00', 'justin.gilbert@ucc.on.ca'),
(8, 'justin', 'c7bc3fe2ee23c7b4fdc54446dc9d6f642b9f8c1a9c7a555ab1bda5fbde201cae', '6fb7e5615d07fb5a', 'lolitsjustins@gmail.com'),
(9, 'jgilbert3', '37c74b9c03a0ee263652b87ba9d7a1cdc7fa283d3471105a8ce31502abfd6e84', '2784cdfd7da1cae6', 'j@g.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `symbols`
--
ALTER TABLE `symbols`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `symbols`
--
ALTER TABLE `symbols`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;